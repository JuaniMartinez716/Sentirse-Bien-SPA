def turno_helper(turno) -> dict:
    return {
        "id": str(turno["_id"]),
        "cliente_id": turno["cliente_id"],
        "fecha": turno["fecha"],
        "duracion": turno["duracion"],
        "servicio": turno["servicio"],
        "estado": turno["estado"],
        "notas": turno.get("notas", "")
    }