from fastapi import APIRouter, HTTPException, status
from models.turno import TurnoCreate, TurnoOut
from schemas.turno import turno_helper
from api.dependencies import data_base
from bson import ObjectId


rt = APIRouter(
    prefix="/turnos",
    tags=["Turnos"],
    responses={status.HTTP_404_NOT_FOUND: {"message": "No encontrado"}}
)

turnos_collection = data_base.turnos


rt.get("/", response_model=list[TurnoOut])
async def turno():
    return [turno_helper(turno) for turno in turnos_collection.find_one({})]

rt.get("/{id}", response_model=TurnoOut)
async def obtener_turno_por_id(id: str):
    turno = obtener_turno(id)
    if turno is None:
        raise HTTPException(status_code=404, detail="Turno no encontrado")
    return turno

@rt.post("/", response_model=TurnoOut)
async def crear_nuevo_turno(turno: TurnoCreate):
    nuevo_turno = crear_turno(turno)
    return nuevo_turno



def crear_turno(turno_data: TurnoCreate) -> dict:
    turno = turno_data.dict()
    turno["estado"] = "pendiente"
    result = turnos_collection.insert_one(turno)  
    created_turno = turnos_collection.find_one({"_id": result.inserted_id})
    return turno_helper(created_turno)

def obtener_turno(id: str) -> dict:
    turno = turnos_collection.find_one({"_id": ObjectId(id)})
    if turno:
        return turno_helper(turno)