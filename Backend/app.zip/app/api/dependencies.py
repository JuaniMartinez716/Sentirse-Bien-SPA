from pymongo import MongoClient

data_base = MongoClient().SentirseBienDB